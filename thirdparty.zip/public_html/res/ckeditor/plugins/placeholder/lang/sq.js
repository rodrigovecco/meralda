/**
 * @license Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */

CKEDITOR.plugins.setLang( 'placeholder', 'sq', {
	title: 'Karakteristikat e Mbajtësit të Vendit',
	toolbar: 'Krijo Mabjtës Vendi',
	name: 'Placeholder Name', // MISSING
	invalidName: 'The placeholder can not be empty and can not contain any of following characters: [, ], <, >', // MISSING
	pathName: 'placeholder' // MISSING
} );
