/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */
CKEDITOR.editorConfig = function( config ) {
	//config.toolbar_OpenXML = [[ 'Format','Bold', 'Italic', 'Underline', 'Strike','NumberedList', 'BulletedList']];
	config.toolbar_OpenXML = [[ 'Source','Bold', 'Italic', 'Underline', 'Strike','NumberedList', 'BulletedList']];
	// Define changes to default configuration here. For example:
	// config.language = 'fr';
	// config.uiColor = '#AADC6E';
};

